﻿using System;

namespace ZebraPrinterSample
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

