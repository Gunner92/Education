﻿using System;

namespace TabBar
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

