﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace TabBar.Droid
{
	[Activity (Label = "TabBar.Droid", MainLauncher = true, Icon = "@drawable/icon")]
	public class MainActivity : Activity
	{
		int count = 1;

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

            this.ActionBar.NavigationMode = ActionBarNavigationMode.Tabs;
			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);

            ActionBar.Tab firstTab = ActionBar.NewTab();
            firstTab.SetText("FİRST TAB");
            firstTab.SetIcon(Resource.Drawable.Icon);
            firstTab.TabSelected += FirstTab_TabSelected;

            ActionBar.Tab secondTab = ActionBar.NewTab();
            secondTab.SetText("FİRST TAB");
            secondTab.SetIcon(Resource.Drawable.Icon);
            secondTab.TabSelected += SecondTab_TabSelected;


            this.ActionBar.AddTab(firstTab);
            this.ActionBar.AddTab(secondTab);

            // Get our button from the layout resource,
            // and attach an event to it
            Button button = FindViewById<Button> (Resource.Id.myButton);
			
			button.Click += delegate {
				button.Text = string.Format ("{0} clicks!", count++);
			};
		}

        private void SecondTab_TabSelected(object sender, ActionBar.TabEventArgs e)
        {
            SetContentView(Resource.Layout.secondLayout);
        }

        private void FirstTab_TabSelected(object sender, ActionBar.TabEventArgs e)
        {
            SetContentView(Resource.Layout.Main);
        }
    }
}


