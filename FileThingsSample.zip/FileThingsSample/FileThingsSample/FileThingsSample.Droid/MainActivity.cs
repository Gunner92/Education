﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using System.Threading.Tasks;
using System.Net;
using System.IO;

namespace FileThingsSample.Droid
{
	[Activity (Label = "FileThingsSample.Droid", MainLauncher = true, Icon = "@drawable/icon")]
	public class MainActivity : Activity
	{
		int count = 1;

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);

			// Get our button from the layout resource,
			// and attach an event to it
			Button button = FindViewById<Button> (Resource.Id.myButton);
			
			button.Click += async delegate {
              var value = await DownloadFile( new System.Uri("http://www.pdf995.com/samples/pdf.pdf"));
                OpenDocument(value);
            };
		}

        //public  void OpenFile(string path)
        //{
        //    RunOnUiThread(async () =>
        //    {
        //        var value = await OpenDocument(path);
        //    });
        //}

        public async Task<string> DownloadFile(Uri fileUri)
        {
            var result = new TaskCompletionSource<string>();

            var client = new WebClient();
            string storagePath = Android.OS.Environment.ExternalStorageDirectory.AbsolutePath;
            //			 = System.Environment.GetFolderPath();

            var extension = System.IO.Path.GetExtension(fileUri.ToString());

            string localFilename = "testfile1" + extension;
            var localpath = System.IO.Path.Combine(storagePath, localFilename);
            var filestream = System.IO.File.Create(localpath);

            client.OpenReadCompleted += async (sender, e) =>
            {
                try
                {
                    using (var sw = new StreamWriter(filestream))
                    {
                        await e.Result.CopyToAsync(sw.BaseStream);
                    }

                    result.SetResult(localpath);

                }
                catch (Exception ex)
                {
                    result.TrySetException(ex);
                }
            };
            //Async read file on the internet
            client.OpenReadAsync(fileUri, localpath);

            var taskresult = await result.Task;
            return taskresult;

        }

        private async Task<bool> OpenDocument(string filePath)
        {
            var result = new TaskCompletionSource<bool>();

            if (!System.IO.File.Exists(filePath))
            {
                var fileEx = new System.IO.FileNotFoundException("File to open not found", filePath);
                result.SetException(fileEx);
                //return
            }

            try
            {
                var targetFile = new Java.IO.File(filePath);
                var fileExtension = System.IO.Path.GetExtension(filePath);

                var targetUri = global::Android.Net.Uri.FromFile(targetFile);

                var intent = new Intent(Intent.ActionView);

                var mimeType = "application/*";
                switch (fileExtension)
                {
                    case ".pdf":
                        mimeType = "application/pdf";
                        break;
                    case ".doc":
                    case ".docx":
                        mimeType = "application/msword";
                        break;
                    case ".txt":
                        mimeType = "text/plain";
                        break;
                }

                intent.SetDataAndType(targetUri, mimeType);

                intent.SetFlags(ActivityFlags.NewTask);

                StartActivity(Intent.CreateChooser(intent, "Choose an Application:"));

                result.SetResult(true);
            }
            catch (Exception e)
            {
                result.SetException(e);
            }

            //Wait for the activity
            var tResult = await result.Task;

            return tResult;
        }
    }
}


