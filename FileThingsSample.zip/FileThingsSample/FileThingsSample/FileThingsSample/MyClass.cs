﻿using System;

namespace FileThingsSample
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

