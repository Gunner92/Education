﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using System.Collections.ObjectModel;

namespace DynamicForms.Droid
{
	[Activity (Label = "DynamicForms.Droid", MainLauncher = true, Icon = "@drawable/icon")]
	public class MainActivity : Activity
	{
        MyReturn returnedItems = new MyReturn();
        protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);
            returnedItems = Newtonsoft.Json.JsonConvert.DeserializeObject<MyReturn>(DynamicFormJSON.myjson);
            // Set our view from the "main" layout resource
            SetContentView (Resource.Layout.Main);

            // Get our button from the layout resource,
            // and attach an event to it
            LinearLayout layout = FindViewById<LinearLayout> (Resource.Id.customArea);
            layout.SetBackgroundColor(Android.Graphics.Color.Rgb(returnedItems.FormColor.RED, returnedItems.FormColor.GREEN, returnedItems.FormColor.BLUE));
            AddLabel(layout);
        }
        void AddLabel(LinearLayout layout )
        {
            for (int i = 0; i < returnedItems.boxes.Count; i++)
            {
                TextView txt = new TextView(this);
                txt.Text = returnedItems.boxes[i].Text;
                txt.Gravity = GravityFlags.Center;
                txt.TextSize = returnedItems.boxes[i].FontSize;
                txt.SetTextColor(Android.Graphics.Color.Rgb(returnedItems.boxes[i].TextColor.RED, returnedItems.boxes[i].TextColor.GREEN, returnedItems.boxes[i].TextColor.BLUE));
                layout.AddView(txt);
            }
        }
	}
}


