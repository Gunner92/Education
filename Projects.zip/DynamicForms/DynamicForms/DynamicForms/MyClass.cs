﻿using System;
using System.Collections.ObjectModel;

namespace DynamicForms
{
	public class MyReturn
	{
        public ObservableCollection<TextBoxes> boxes { get; set; }
        public RGBColorClass FormColor { get; set; }
    }
    public class TextBoxes
    {
        public RGBColorClass TextColor { get; set; }
        public string Text { get; set; }
        public int FontSize { get; set; }
    }

    public class RGBColorClass
    {
        public int RED { get; set; }
        public int GREEN { get; set; }
        public int BLUE { get; set; }
    }
    public static class DynamicFormJSON
    {
        public static string myjson = "{\"boxes\":[{\"TextColor\":{\"RED\":0,\"GREEN\":0,\"BLUE\":255},\"Text\":\"DENEME\",\"FontSize\":30},{\"TextColor\":{\"RED\":255,\"GREEN\":0,\"BLUE\":0},\"Text\":\"DENEME\",\"FontSize\":15},{\"TextColor\":{\"RED\":0,\"GREEN\":255,\"BLUE\":0},\"Text\":\"DENEME\",\"FontSize\":25},{\"TextColor\":{\"RED\":0,\"GREEN\":0,\"BLUE\":0},\"Text\":\"DENEME\",\"FontSize\":30}],\"FormColor\":{\"RED\":255,\"GREEN\":255,\"BLUE\":255}}";

    }
}

