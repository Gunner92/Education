﻿using LinkOS.Plugin;
using LinkOS.Plugin.Abstractions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using Windows.Devices.Bluetooth;
using Windows.Devices.Enumeration;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=391641

namespace ZebraPrinterSample.WinPhone
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        const string tag = "BasicPrintApp";
        IConnection connection;

        public MainPage()
        {
            this.InitializeComponent();

            this.NavigationCacheMode = NavigationCacheMode.Required;
        }

        BluetoothLEDevice currentDevice { get; set; }
        string deviceName = "Philips AEA1000";

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            // TODO: Prepare page for display here.

            // TODO: If your application contains multiple pages, ensure that you are
            // handling the hardware Back button by registering for the
            // Windows.Phone.UI.Input.HardwareButtons.BackPressed event.
            // If you are using the NavigationHelper provided by some templates,
            // this event is handled for you.
            Button.Click += async delegate
            {
                try
                {
                    var devices = await DeviceInformation.FindAllAsync(DeviceClass.All);
                    foreach (DeviceInformation di in devices)
                    {
                        BluetoothLEDevice bleDevice = await BluetoothLEDevice.FromIdAsync(di.Id);
                        if (bleDevice.Name == deviceName)
                        {
                            currentDevice = bleDevice;
                            break;
                        }
                    }
                }
                catch (Exception)
                {
                   
                }
                
            };
            
        }

        private void Start_Print(string address)
        {

            // Bluetooth communications must be handled on a separate thread and it's
            //    best practice to handle network coms on it as well
            new Task(() =>
            {
                Print(address);
            }).Start();
        }

        private void Print(string address)
        {
            string zpl = "^XA^LL200^FO30,20^A0N,30,30^FDHello World^FS^XZ";

            try
            {
                if ((connection == null) || (!connection.IsConnected))
                {
                    connection = ConnectionBuilder.Current.Build(address);
                    connection.Open();
                }
                if ((SetPrintLanguage(connection)) && (CheckPrinterStatus(connection)))
                {
                    //connection.Write(System.Text.StringToAscii(zpl));
                }
            }
            catch (Exception e)
            {
                //if the device is unable to connect, an exception is thrown
                System.Diagnostics.Debug.WriteLine(e.ToString());
            }
            finally
            {
                //this.RunOnUiThread(() =>
                //{
                    //button.Enabled = true;
                    //});
            }
        }

        private bool SetPrintLanguage(IConnection connection)
        {
            string setLanguage = "! U1 setvar \"device.languages\" \"zpl\"\r\n\r\n! U1 getvar \"device.languages\"\r\n\r\n";
            byte[] response = connection.SendAndWaitForResponse( StringToAscii(setLanguage), 500, 500);
            string s = AsciiToString(response);
            if (!s.Contains("zpl"))
            {
                return false;
            }
            return true;
        }

        private bool CheckPrinterStatus(IConnection connection)
        {
            IZebraPrinter printer = ZebraPrinterFactory.Current.GetInstance(PrinterLanguage.ZPL, connection);
            IPrinterStatus status = printer.CurrentStatus;
            if (!status.IsReadyToPrint)
            {
                System.Diagnostics.Debug.WriteLine("Printer in Error: " + status.ToString());
                //Android.Util.Log.Debug(tag, "Printer in Error: " + status.ToString());
            }
            return true;
        }

        public static byte[] StringToAscii(string s)
        {
            byte[] retval = new byte[s.Length];
            for (int ix = 0; ix < s.Length; ++ix)
            {
                char ch = s[ix];
                if (ch <= 0x7f) retval[ix] = (byte)ch;
                else retval[ix] = (byte)'?';
            }
            return retval;
        }

        string AsciiToString(byte[] bytes)
        {
            return string.Concat(
              (bytes.Select(b => (b <= 0x7f ? (char)b : '?').ToString()))
              .ToArray()
              );
        }


        //public void PrintBluetooth()
        //{
        //    IConnection connection = ConnectionBuilder.Current.Build("BT:00:22:33:44:55:66");
        //    Print(connection);
        //}
        //public void Print(IConnection connection)
        //{
        //    string zpl = "^XA^POI^MNN^LL90^PW400^FO20,20^A0N,50,50^FDTEST^FS^XZ";
        //    try
        //    {
        //        connection.Open();
        //        if (!CheckPrinterLanguage(connection))
        //            return;
        //        if (!PreCheckPrinterStatus(connection))
        //            return;
        //        connection.Write(System.Text.Encoding.UTF8.GetBytes(setToZPL + zpl));
        //        PostPrintCheckStatus(connection);
        //    }
        //    catch (Exception e)
        //    {
        //        System.Diagnostics.Debug.WriteLine("Exception:" + e.Message);
        //    }
        //    finally
        //    {
        //        if (connection.IsConnected)
        //            connection.Close();
        //    }
        //}
        //public bool CheckPrinterLanguage(IConnection connection)
        //{
        //    //  Set the printer command languege
        //    connection.Write(System.Text.Encoding.UTF8.GetBytes("! U1 setvar \"device.languages\\" \"zpl\\\r\n"));

        //    byte[] response = connection.SendAndWaitForResponse(System.Text.Encoding.UTF8.GetBytes("! U1 getvar \"device.languages\\\r\n"), 500, 100);

        //    string language = System.Text.Encoding.UTF8.GetString(response, 0, response.Length);
        //    if (!language.Contains("zpl"))
        //    {
        //        ShowErrorAlert("Printer language not set. Not a ZPL printer.");
        //        return false;
        //    }
        //    return true;
        //}
        //public bool PreCheckPrinterStatus(IConnection connection)
        //{
        //    // Check the printer status prior to printing
        //    IZebraPrinter printer = ZebraPrinterFactory.Current.GetInstance(connection);
        //    IPrinterStatus status = printer.CurrentStatus;
        //    if (!status.IsReadyToPrint)
        //    {
        //        System.Diagnostics.Debug.WriteLine("Unable to print. Printer is " + status.Status);
        //        return false;
        //    }
        //    return true;
        //}
        


        //private void StartBluetoothDiscovery()
        //{
        //    IDiscoveryEventHandler handler = DiscoveryHandlerFactory.Current.GetInstance();
        //    handler.OnDiscoveryError += DiscoveryHandler_OnDiscoveryError;
        //    handler.OnDiscoveryFinished += DiscoveryHandler_OnDiscoveryFinished;
        //    handler.OnFoundPrinter += DiscoveryHandler_OnFoundPrinter;
        //    //For Android 
        //    BluetoothDiscoverer.Current.FindPrinters(this, handler);
        //    //For iOS
        //    // BluetoothDiscoverer.Current.FindPrinters(null, handler);
        //    //For Forms apps: implement the previous two methods in OS code projects (PrinterDiscoveryImplementation.cs)
        //    //DependencyService.Get<IPrinterDiscovery>().FindBluetoothPrinters(handler);
        //}

        //void BluethoothMessage(bool temp)
        //{
        //    MessageDialog dialog = new MessageDialog("Bluethooth","connect");
        //    dialog.ShowAsync();
        //}
        //private void DiscoveryHandler_OnFoundPrinter(IDiscoveryHandler handler, IDiscoveredPrinter discoveredPrinter)
        //{
        //    BluethoothMessage(true);
        //    Start_Print(discoveredPrinter.Address);
        //}

        //private void DiscoveryHandler_OnDiscoveryFinished(IDiscoveryHandler handler)
        //{
        //    BluethoothMessage(false);
        //}

        //private void DiscoveryHandler_OnDiscoveryError(IDiscoveryHandler handler, string message)
        //{
        //    BluethoothMessage(false);
        //}

        //private void OnFoundPrinter(IDiscoveryHandler handler, IDiscoveredPrinter discoveredPrinter)
        //{
        //    // Device.BeginInvokeOnMainThread(() => {
        //    //     printerList.Add(discoveredPrinter);
        //    // });
        //    BluethoothMessage(true);
        //    Start_Print(discoveredPrinter.Address);
        //}
        //private void OnDiscoveryError(IDiscoveryHandler handler, string message)
        //{
        //    BluethoothMessage(false);
        //    System.Diagnostics.Debug.WriteLine("Discovery Error: " + message);
        //}
        //private void OnDiscoveryFinished(IDiscoveryHandler handler, string message)
        //{
        //    System.Diagnostics.Debug.WriteLine("Discovery Compete");
        //}
    }
}
