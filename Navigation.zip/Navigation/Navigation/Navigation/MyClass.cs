﻿using System;

namespace Navigation
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

